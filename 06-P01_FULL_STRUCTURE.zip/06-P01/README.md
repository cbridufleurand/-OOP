# Program 1 - Image Tool

## Name
Claude Dufleurand

## Course
2143 - Object Oriented Programming

## Compile

g++ -std=c++17 -O2 -Wall -Wextra -pedantic -Iinclude src/main.cpp -o imgtool

## Run

./imgtool images/Hulda.png output.png
