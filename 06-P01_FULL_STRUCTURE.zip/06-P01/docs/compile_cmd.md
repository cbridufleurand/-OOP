# Compile Command Breakdown

g++
- GNU C++ compiler

-std=c++17
- Use the C++17 standard

-O2
- Optimization level 2

-Wall
- Enable common warnings

-Wextra
- Enable extra warnings

-pedantic
- Strict ISO C++ compliance

-Iinclude
- Search include/ folder for headers

src/main.cpp
- Source file

-o imgtool
- Output executable name
