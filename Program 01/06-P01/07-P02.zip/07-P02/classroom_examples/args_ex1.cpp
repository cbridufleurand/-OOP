// args_ex1.cpp
// Example sketch of what NOT to do.

#include <iostream>

int main() {
    std::cout << "Do not hardcode argv positions without checking argc first.\n";
    return 0;
}
