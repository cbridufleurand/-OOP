// args_ex2.cpp
// Factory pattern skeleton example.

#include <iostream>

class ExampleArgs {
public:
    static ExampleArgs parse(int argc, char* argv[]) {
        ExampleArgs args;
        return args;
    }

    void print() const {
        std::cout << "Factory pattern example\n";
    }
};

int main(int argc, char* argv[]) {
    ExampleArgs args = ExampleArgs::parse(argc, argv);
    args.print();
    return 0;
}
