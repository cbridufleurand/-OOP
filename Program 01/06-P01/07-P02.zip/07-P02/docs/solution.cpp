// Reference solution placeholder.
// Try your own solution first.
