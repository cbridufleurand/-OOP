# Program 2 - Args Parser

Name: Claude Dufleurand  
Class: CMPS 2143  
Assignment: Program 2  
Date: March 2026  

## Description

This program builds a command-line argument parser for `imgtool`.

Program 2 does not do image processing yet. It only reads command-line arguments, checks if they are valid, stores them inside an `Args` object, and prints the result.

---

## Build

Compile from inside the `07-P02` folder:

```bash
g++ -std=c++17 -O2 -Wall -Wextra -pedantic src/main.cpp src/Args.cpp -o imgtool
```

---

## Usage

```bash
./imgtool <input_image> <output_image> [options]
```

Accepted image extensions:

```text
.png
.jpg
.jpeg
.bmp
.ppm
```

---

## Supported Flags

| Long Form | Short Form | Description |
|---|---|---|
| `--grayscale` | `-g` | Convert to grayscale |
| `--blur` | `-l` | Apply blur filter |
| `--flipH` | `-h` | Flip horizontally |
| `--flipV` | `-v` | Flip vertically |

---

## Supported Options With Values

| Long Form | Short Form | Valid Values |
|---|---|---|
| `--brighten N` | `-b N` | integer from -255 to 255 |
| `--rotate N` | `-r N` | 0, 90, 180, or 270 |

Long options also support equals format:

```bash
--brighten=20
--rotate=90
```

---

## Example Commands

```bash
./imgtool in.png out.png --grayscale --brighten 20
```

```bash
./imgtool in.jpg out.png -g -l -b 50 -r 90
```

```bash
./imgtool in.png out.png --brighten=20 --rotate=180
```

Error example:

```bash
./imgtool in.png
```

Error example:

```bash
./imgtool in.png out.png --graycale
```

---

## Example Output

```text
INPUT  : in.png
OUTPUT : out.png
FLAGS  : grayscale blur
PARAMS : brighten=20 rotate=90
```

---

## What I Learned

In this program, I learned how to parse command-line arguments in C++.

I also learned how to validate input, check file extensions, handle errors, use a class to store program configuration, and separate code into a header file and implementation file.
